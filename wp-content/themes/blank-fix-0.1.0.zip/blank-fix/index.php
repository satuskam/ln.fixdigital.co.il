<?php
/**
 * The main template file.
 */


get_header();
?>

<section id="main" role="main">
    <?php the_content(); ?>
</section>

<?php
get_footer();