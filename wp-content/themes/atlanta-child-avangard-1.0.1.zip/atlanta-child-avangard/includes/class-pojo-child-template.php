<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( class_exists( 'Pojo_Theme_Template' ) ) {
	
	class Pojo_Child_Template extends Pojo_Theme_Template {
		
	}
	
}